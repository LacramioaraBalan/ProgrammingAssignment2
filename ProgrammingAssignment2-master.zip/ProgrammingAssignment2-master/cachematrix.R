## Put comments here that give an overall description of what your
## functions do

## Write a short comment describing this function

a <- matrix(nrow=5,sample(1:35, 35),ncol=7)
library(MASS)

makeCacheMatrix <- function (inputMTX){ # the function code
    cacheSolve <- ginv(inputMTX) # calculating the inverse of the matrix
    return(cacheSolve)  # returning the answer, the inverse matrix
}

makeCacheMatrix(a) 
        ## Return a matrix that is the inverse of 'x'

